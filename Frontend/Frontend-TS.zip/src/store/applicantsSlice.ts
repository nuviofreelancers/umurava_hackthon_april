import { createSlice, createAsyncThunk } from "@reduxjs/toolkit";
import { applicants as applicantsApi } from "@/api/backend";

interface ApplicantsState {
  list: unknown[];
  selected: unknown | null;
  loading: boolean;
  error: string | null;
}

export const fetchApplicants      = createAsyncThunk("applicants/fetchAll", () => applicantsApi.list());
export const fetchApplicantsByJob = createAsyncThunk("applicants/byJob",    (jobId: string) => applicantsApi.listByJob(jobId));
export const fetchApplicant       = createAsyncThunk("applicants/fetchOne", (id: string) => applicantsApi.get(id));
export const createApplicant      = createAsyncThunk("applicants/create",   (data: unknown) => applicantsApi.create(data));
export const bulkCreateApplicants = createAsyncThunk("applicants/bulk",     (data: unknown[]) => applicantsApi.bulkCreate(data));
export const updateApplicant      = createAsyncThunk("applicants/update",   ({ id, data }: { id: string; data: unknown }) => applicantsApi.update(id, data));
export const deleteApplicant      = createAsyncThunk("applicants/delete",   (id: string) => applicantsApi.delete(id).then(() => id));

const applicantsSlice = createSlice({
  name: "applicants",
  initialState: {
    list: [],
    selected: null,
    loading: false,
    error: null,
  } as ApplicantsState,
  reducers: {
    clearApplicants: (state) => { state.list = []; },
  },
  extraReducers: (builder) => {
    builder
      .addCase(fetchApplicants.pending,       (state)         => { state.loading = true; })
      .addCase(fetchApplicants.fulfilled,     (state, action) => { state.loading = false; state.list = action.payload as unknown[]; })
      .addCase(fetchApplicantsByJob.fulfilled,(state, action) => { state.loading = false; state.list = action.payload as unknown[]; })
      .addCase(fetchApplicant.fulfilled,      (state, action) => { state.selected = action.payload; })
      .addCase(createApplicant.fulfilled,     (state, action) => { (state.list as unknown[]).unshift(action.payload); })
      .addCase(bulkCreateApplicants.fulfilled,(state, action) => {
        const payload = action.payload as { applicants?: unknown[] };
        state.list = [...(payload.applicants || []), ...state.list];
      })
      .addCase(updateApplicant.fulfilled,     (state, action) => {
        const payload = action.payload as { id: string };
        const idx = (state.list as { id: string }[]).findIndex(a => a.id === payload.id);
        if (idx !== -1) (state.list as unknown[])[idx] = payload;
        if ((state.selected as { id: string } | null)?.id === payload.id) state.selected = payload;
      })
      .addCase(deleteApplicant.fulfilled,     (state, action) => {
        state.list = (state.list as { id: string }[]).filter(a => a.id !== action.payload);
      });
  },
});

export const { clearApplicants } = applicantsSlice.actions;
export default applicantsSlice.reducer;
