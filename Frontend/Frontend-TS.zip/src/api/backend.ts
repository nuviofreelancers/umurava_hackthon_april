const API_BASE = import.meta.env.VITE_API_BASE_URL || 'http://localhost:5000/api';

async function request<T = unknown>(path: string, options: RequestInit = {}): Promise<T> {
  const token = localStorage.getItem("hr_token");
  const res = await fetch(`${API_BASE}${path}`, {
    headers: {
      "Content-Type": "application/json",
      ...(token ? { Authorization: `Bearer ${token}` } : {}),
      ...(options.headers as Record<string, string> ?? {}),
    },
    ...options,
  });
  
  if (!res.ok) {
    const err = await res.json().catch(() => ({ message: res.statusText }));
    const error = Object.assign(new Error(err.message || "Request failed"), { status: res.status });
    throw error;
  }
  
  const data = await res.json();
  
  // 🔧 AUTO-UNWRAP common response patterns (fixes ALL pages at once!)
  // If backend returns { jobs: [...] }, { data: [...] }, { applicants: [...] }, etc.
  if (data && typeof data === 'object') {
    // Extract array if it's wrapped in common keys
    const arrayKeys = ['jobs', 'data', 'applicants', 'results', 'users', 'items'];
    for (const key of arrayKeys) {
      if (Array.isArray(data[key])) {
        return data[key] as T; // Return the unwrapped array
      }
    }
  }
  
  return data as T;
}

// ─── Auth ────────────────────────────────────────────────────
export const auth = {
  login:    (email: string, password: string) =>
    request<{ token: string; user: { id: string; full_name: string; email: string } }>(
      "/auth/login", { method: "POST", body: JSON.stringify({ email, password }) }
    ),
  me:       () => request<{ id: string; full_name: string; email: string }>("/auth/me"),
  updateMe: (data: Partial<{ full_name: string; email: string; password: string }>) =>
    request("/auth/me", { method: "PUT", body: JSON.stringify(data) }),
  logout: () => {
    localStorage.removeItem("hr_token");
    window.location.href = "/login";
  },
};

// ─── Jobs ────────────────────────────────────────────────────
export const jobs = {
  list:   ()                    => request("/jobs"),
  get:    (id: string)          => request(`/jobs/${id}`),
  create: (data: unknown)       => request("/jobs",       { method: "POST",   body: JSON.stringify(data) }),
  update: (id: string, data: unknown) => request(`/jobs/${id}`, { method: "PUT", body: JSON.stringify(data) }),
  delete: (id: string)          => request(`/jobs/${id}`, { method: "DELETE" }),
};

// ─── Applicants ──────────────────────────────────────────────
export const applicants = {
  list:       ()                               => request("/applicants"),
  listByJob:  (jobId: string)                  => request(`/applicants?job_id=${jobId}`),
  get:        (id: string)                     => request(`/applicants/${id}`),
  create:     (data: unknown)                  => request("/applicants",       { method: "POST",   body: JSON.stringify(data) }),
  bulkCreate: (data: unknown[])                => request("/applicants/bulk",  { method: "POST",   body: JSON.stringify({ applicants: data }) }),
  update:     (id: string, data: unknown)      => request(`/applicants/${id}`, { method: "PUT",    body: JSON.stringify(data) }),
  delete:     (id: string)                     => request(`/applicants/${id}`, { method: "DELETE" }),
};

// ─── Screening Results ────────────────────────────────────────
export const results = {
  list:              ()                   => request("/results"),
  listByJob:         (jobId: string)      => request(`/results?job_id=${jobId}`),
  listByApplicant:   (applicantId: string)=> request(`/results?applicant_id=${applicantId}`),
  create:            (data: unknown)      => request("/results",                      { method: "POST",   body: JSON.stringify(data) }),
  bulkCreate:        (data: unknown[])    => request("/results/bulk",                 { method: "POST",   body: JSON.stringify({ results: data }) }),
  deleteByJob:       (jobId: string)      => request(`/results/by-job/${jobId}`,               { method: "DELETE" }),
  deleteByApplicant: (applicantId: string)=> request(`/results/by-applicant/${applicantId}`,   { method: "DELETE" }),
};

// ─── AI Screening ─────────────────────────────────────────────
export const screening = {
  run: (jobId: string, weights: Record<string, number>) =>
    request("/screen", { method: "POST", body: JSON.stringify({ job_id: jobId, weights }) }),
};

// ─── File Upload ──────────────────────────────────────────────
export const uploads = {
  parseCandidates: async (file: File, jobId?: string): Promise<unknown> => {
    const formData = new FormData();
    formData.append("file", file);
    if (jobId) formData.append("job_id", jobId);
    const token = localStorage.getItem("hr_token");
    
    // 🔧 Also fix upload endpoints to use API_BASE
    const res = await fetch(`${API_BASE}/upload/candidates`, {
      method: "POST",
      headers: token ? { Authorization: `Bearer ${token}` } : {},
      body: formData,
    });
    if (!res.ok) throw new Error("Upload failed");
    return res.json();
  },

  parseJobs: async (file: File): Promise<unknown> => {
    const formData = new FormData();
    formData.append("file", file);
    const token = localStorage.getItem("hr_token");
    
    // 🔧 Also fix upload endpoints to use API_BASE
    const res = await fetch(`${API_BASE}/upload/jobs`, {
      method: "POST",
      headers: token ? { Authorization: `Bearer ${token}` } : {},
      body: formData,
    });
    if (!res.ok) throw new Error("Upload failed");
    return res.json();
  },
};